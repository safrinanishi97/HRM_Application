﻿using HRMApiApp.DAL.Interfaces;
using HRMApiApp.Model;
using HRMApiApp.Models;
using HRMApiApp.ViewModels;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Transactions;

namespace HRMApiApp.DAL
{
    

        public class EmployeeRepository : IEmployeeRepository
        {
            private readonly HanaHrmContext _context;

            public EmployeeRepository(HanaHrmContext context)
            {
                _context = context;
            }

            public async Task<Employee?> GetByIdAsync(int id)
            {
                return await _context.Employees
                    .Include(e => e.EmployeeDocuments)
                    .Include(e => e.EmployeeEducationInfos)
                    .Include(e => e.EmployeeProfessionalCertifications)
                    .FirstOrDefaultAsync(e => e.Id == id && e.IsActive != false);
            }

            public async Task<List<Employee>> GetAllAsync()
            {
                return await _context.Employees
                    .Include(e => e.EmployeeDocuments)
                    .Include(e => e.EmployeeEducationInfos)
                    .Include(e => e.EmployeeProfessionalCertifications)
                    .Where(e => e.IsActive != false)
                    .ToListAsync();
            }

            public async Task<Employee> CreateAsync(Employee employee)
            {
                _context.Employees.Add(employee);
                await _context.SaveChangesAsync();
                return employee;
            }

            public async Task<Employee> UpdateAsync(Employee employee)
            {
                _context.Employees.Update(employee);
                await _context.SaveChangesAsync();
                return employee;
            }

            public async Task<bool> SoftDeleteAsync(int id)
            {
                var employee = await _context.Employees.FindAsync(id);
                if (employee == null)
                    return false;

                employee.IsActive = false;
                employee.SetDate = DateTime.UtcNow;
                await _context.SaveChangesAsync();
                return true;
            }
        }
        //Hard delete
        //public bool DeleteEmployee(int id)
        //{
        //    var employee = _context.Employees.FirstOrDefault(s=>s.Id==id);
        //    if (employee == null)
        //    {
        //        return false; 
        //    }
        //    _context.Employees.Remove(employee);
        //    _context.SaveChanges();
        //    return true;

        //}

        //soft delete
        //public async Task<bool> DeleteEmployee(int id, int idClient) { 
        //var employee =  await _context.Employees.FirstOrDefaultAsync(e => e.IdClient == 10001001 && e.Id == id);
        //    // FirstOrDefaultAsync(e => e.IdClient== idClient && e.Id == id)

        //    if (employee == null)
        //    {
        //        return false;
        //    }
        //    employee.IsActive = false;
        //    await _context.SaveChangesAsync();
        //    return true;
        //}

       
    }

