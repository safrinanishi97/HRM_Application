﻿using HRMApiApp.BLL.Interfaces;
using HRMApiApp.DAL.Interfaces;
using HRMApiApp.DTO;
using HRMApiApp.Models;
using HRMApiApp.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRMApiApp.BLL
{
    public class EmployeeService : IEmployeeService
    {
        private readonly IEmployeeRepository _employeeRepository;

        public EmployeeService(IEmployeeRepository employeeRepository)
        {
            _employeeRepository = employeeRepository;
        }

        public async Task<EmployeeDTO?> GetByIdAsync(int id)
        {
            var employee = await _employeeRepository.GetByIdAsync(id);
            if (employee == null) return null;

            var emloyee = new EmployeeDTO
            {
                Id = employee.Id,
                EmployeeName = employee.EmployeeName,
                EmployeeNameBangla = employee.EmployeeNameBangla,
                FatherName = employee.FatherName,
                MotherName = employee.MotherName,
                BirthDate = employee.BirthDate,
                JoiningDate = employee.JoiningDate,
                Address = employee.Address,
                PresentAddress = employee.PresentAddress,
                NationalIdentificationNumber = employee.NationalIdentificationNumber,
                ContactNo = employee.ContactNo,
                IsActive = employee.IsActive,

                Documents = employee.EmployeeDocuments.Select(d => new EmployeeDocumentDTO
                {
                    Id = d.Id,
                    DocumentName = d.DocumentName,
                    FileName = d.FileName,
                    UploadDate = d.UploadDate,
                    UploadedFileExtention = d.UploadedFileExtention,
                    UploadedFile = d.UploadedFile
                }).ToList(),

                EducationInfos = employee.EmployeeEducationInfos.Select(e => new EmployeeEducationInfoDTO
                {
                    Id = e.Id,
                    IdEducationLevel = e.IdEducationLevel,
                    IdEducationExamination = e.IdEducationExamination,
                    IdEducationResult = e.IdEducationResult,
                    Cgpa = e.Cgpa,
                    ExamScale = e.ExamScale,
                    Marks = e.Marks,
                    Major = e.Major,
                    PassingYear = e.PassingYear,
                    InstituteName = e.InstituteName,
                    IsForeignInstitute = e.IsForeignInstitute,
                    Duration = e.Duration,
                    Achievement = e.Achievement
                }).ToList(),

                Certifications = employee.EmployeeProfessionalCertifications.Select(c => new EmployeeProfessionalCertificationDTO
                {
                    Id = c.Id,
                    CertificationTitle = c.CertificationTitle,
                    CertificationInstitute = c.CertificationInstitute,
                    InstituteLocation = c.InstituteLocation,
                    FromDate = c.FromDate,
                    ToDate = c.ToDate
                }).ToList()
            };
            return emloyee;
        }

        public async Task<List<EmployeeDTO>> GetAllAsync()
        {
            var employees = await _employeeRepository.GetAllAsync();
            return employees.Select(MapToEmployeeDTO).ToList();
        }

        public async Task<EmployeeDTO> CreateAsync(EmployeeCreateDTO employeeDto)
        {
            var employee = new Employee
            {
                IdClient = employeeDto.IdClient,
                EmployeeName = employeeDto.EmployeeName,
                EmployeeNameBangla = employeeDto.EmployeeNameBangla,
                FatherName = employeeDto.FatherName,
                MotherName = employeeDto.MotherName,
                BirthDate = employeeDto.BirthDate,
                JoiningDate = employeeDto.JoiningDate,
                Address = employeeDto.Address,
                PresentAddress = employeeDto.PresentAddress,
                NationalIdentificationNumber = employeeDto.NationalIdentificationNumber,
                ContactNo = employeeDto.ContactNo,
                IsActive = true,
                SetDate = DateTime.UtcNow,

                EmployeeDocuments = employeeDto.Documents.Select(d => new EmployeeDocument
                {
                    IdClient = d.IdClient,
                    DocumentName = d.DocumentName,
                    FileName = d.FileName,
                    UploadDate = d.UploadDate,
                    UploadedFileExtention = d.UploadedFileExtention,
                    UploadedFile = d.UploadedFile,
                    SetDate = DateTime.UtcNow
                }).ToList(),

                EmployeeEducationInfos = employeeDto.EducationInfos.Select(e => new EmployeeEducationInfo
                {
                    IdClient = e.IdClient,
                    IdEducationLevel = e.IdEducationLevel,
                    IdEducationExamination = e.IdEducationExamination,
                    IdEducationResult = e.IdEducationResult,
                    Cgpa = e.Cgpa,
                    ExamScale = e.ExamScale,
                    Marks = e.Marks,
                    Major = e.Major,
                    PassingYear = e.PassingYear,
                    InstituteName = e.InstituteName,
                    IsForeignInstitute = e.IsForeignInstitute,
                    Duration = e.Duration,
                    Achievement = e.Achievement,
                    SetDate = DateTime.UtcNow
                }).ToList(),

                EmployeeProfessionalCertifications = employeeDto.Certifications.Select(c => new EmployeeProfessionalCertification
                {
                    IdClient = c.IdClient,
                    CertificationTitle = c.CertificationTitle,
                    CertificationInstitute = c.CertificationInstitute,
                    InstituteLocation = c.InstituteLocation,
                    FromDate = c.FromDate,
                    ToDate = c.ToDate,
                    SetDate = DateTime.UtcNow
                }).ToList()
            };

            var createdEmployee = await _employeeRepository.CreateAsync(employee);
            return MapToEmployeeDTO(createdEmployee);
        }

        public async Task<EmployeeDTO?> UpdateAsync(EmployeeUpdateDTO employeeDto)
        {
            var existingEmployee = await _employeeRepository.GetByIdAsync(employeeDto.Id);
            if (existingEmployee == null) return null;

            existingEmployee.IdClient = employeeDto.IdClient;
            existingEmployee.EmployeeName = employeeDto.EmployeeName ?? existingEmployee.EmployeeName;
            existingEmployee.EmployeeNameBangla = employeeDto.EmployeeNameBangla ?? existingEmployee.EmployeeNameBangla;
            existingEmployee.FatherName = employeeDto.FatherName ?? existingEmployee.FatherName;
            existingEmployee.MotherName = employeeDto.MotherName ?? existingEmployee.MotherName;
            existingEmployee.BirthDate = employeeDto.BirthDate ?? existingEmployee.BirthDate;
            existingEmployee.Address = employeeDto.Address ?? existingEmployee.Address;
            existingEmployee.PresentAddress = employeeDto.PresentAddress ?? existingEmployee.PresentAddress;
            existingEmployee.NationalIdentificationNumber = employeeDto.NationalIdentificationNumber ?? existingEmployee.NationalIdentificationNumber;
            existingEmployee.ContactNo = employeeDto.ContactNo ?? existingEmployee.ContactNo;
            existingEmployee.IsActive = employeeDto.IsActive ?? existingEmployee.IsActive;
            existingEmployee.SetDate = DateTime.UtcNow;


            if (employeeDto.Documents != null)
            {

                var documentsToRemove = existingEmployee.EmployeeDocuments
                    .Where(ed => !employeeDto.Documents.Any(d => d.Id == ed.Id))
                    .ToList();

                foreach (var doc in documentsToRemove)
                {
                    existingEmployee.EmployeeDocuments.Remove(doc);
                }


                foreach (var docDto in employeeDto.Documents)
                {
                    var existingDoc = existingEmployee.EmployeeDocuments.FirstOrDefault(d => d.Id == docDto.Id);
                    if (existingDoc != null)
                    {
                        existingDoc.IdClient = docDto.IdClient;
                        existingDoc.DocumentName = docDto.DocumentName;
                        existingDoc.FileName = docDto.FileName;
                        existingDoc.UploadDate = docDto.UploadDate;
                        existingDoc.UploadedFileExtention = docDto.UploadedFileExtention;
                        existingDoc.UploadedFile = docDto.UploadedFile;
                    }
                    else
                    {

                        existingEmployee.EmployeeDocuments.Add(new EmployeeDocument
                        {
                            IdClient = docDto.IdClient,
                            DocumentName = docDto.DocumentName,
                            FileName = docDto.FileName,
                            UploadDate = docDto.UploadDate,
                            UploadedFileExtention = docDto.UploadedFileExtention,
                            UploadedFile = docDto.UploadedFile,
                            SetDate = DateTime.UtcNow
                        });
                    }
                }
            }

            var updatedEmployee = await _employeeRepository.UpdateAsync(existingEmployee);
            return MapToEmployeeDTO(updatedEmployee);
        }

        public async Task<bool> DeleteAsync(int id)
        {
            return await _employeeRepository.SoftDeleteAsync(id);
        }

        private EmployeeDTO MapToEmployeeDTO(Employee employee)
        {
            return new EmployeeDTO
            {
                Id = employee.Id,
                IdClient = employee.IdClient,
                EmployeeName = employee.EmployeeName,
                EmployeeNameBangla = employee.EmployeeNameBangla,
                FatherName = employee.FatherName,
                MotherName = employee.MotherName,
                BirthDate = employee.BirthDate,
                JoiningDate = employee.JoiningDate,
                Address = employee.Address,
                PresentAddress = employee.PresentAddress,
                NationalIdentificationNumber = employee.NationalIdentificationNumber,
                ContactNo = employee.ContactNo,
                IsActive = employee.IsActive,

                Documents = employee.EmployeeDocuments.Select(d => new EmployeeDocumentDTO
                {
                    Id = d.Id,
                    IdClient = d.IdClient,
                    DocumentName = d.DocumentName,
                    FileName = d.FileName,
                    UploadDate = d.UploadDate,
                    UploadedFileExtention = d.UploadedFileExtention,
                    UploadedFile = d.UploadedFile
                }).ToList(),

                EducationInfos = employee.EmployeeEducationInfos.Select(e => new EmployeeEducationInfoDTO
                {
                    Id = e.Id,
                    IdClient = e.IdClient,
                    IdEducationLevel = e.IdEducationLevel,
                    IdEducationExamination = e.IdEducationExamination,
                    IdEducationResult = e.IdEducationResult,
                    Cgpa = e.Cgpa,
                    ExamScale = e.ExamScale,
                    Marks = e.Marks,
                    Major = e.Major,
                    PassingYear = e.PassingYear,
                    InstituteName = e.InstituteName,
                    IsForeignInstitute = e.IsForeignInstitute,
                    Duration = e.Duration,
                    Achievement = e.Achievement
                }).ToList(),

                Certifications = employee.EmployeeProfessionalCertifications.Select(c => new EmployeeProfessionalCertificationDTO
                {
                    Id = c.Id,
                    IdClient = c.IdClient,
                    CertificationTitle = c.CertificationTitle,
                    CertificationInstitute = c.CertificationInstitute,
                    InstituteLocation = c.InstituteLocation,
                    FromDate = c.FromDate,
                    ToDate = c.ToDate
                }).ToList()
            };
        }
    }
}
